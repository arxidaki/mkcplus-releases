#!/bin/sh
# What a package's install and removal scripts do to the people signed in right now.
# Installed as /usr/libexec/mkcplus/session.sh and called by both the .deb's postinst and
# prerm and the .rpm's %post and %preun, so the two cannot drift apart.
#
#   session.sh enable        the engine for whoever is signed in, and start the window
#   session.sh disable       the engine, and stop the window
#   session.sh stop-window   only the window
#
# Nothing in this version's packages asks for `stop-window` any more: the window watches
# its own program and makes way for the new one itself
# (apps/mkcplus-ui/src/replaced.rs), which is the only thing that works when the daily
# timer runs the upgrade rather than a person. It stays here all the same, because on an
# upgrade the package manager lays down the new files and then runs the **old** package's
# removal scripts: a version that still asks for it would meet a script that refused, the
# scriptlet would fail under `set -e`, and the transaction would fail with both versions
# left registered. Measured, on this very change. Whatever a released package's scripts
# call, this file answers for good.
set -e

# A session is a running session bus, which is what `users` misses when the desktop signed
# in by itself.
each_session() {
    for bus in /run/user/*/bus; do
        [ -S "$bus" ] || continue
        id=$(basename "$(dirname "$bus")")
        who=$(id -un "$id" 2>/dev/null) || continue
        "$1" "$who" "$id" "$bus"
    done
}

as_user() {
    who=$1 id=$2 bus=$3
    shift 3
    runuser -u "$who" -- env "XDG_RUNTIME_DIR=/run/user/$id" \
        "DBUS_SESSION_BUS_ADDRESS=unix:path=$bus" "$@" >/dev/null 2>&1 || true
}

enable_one() {
    as_user "$1" "$2" "$3" systemctl --user disable --now mkcplus.service
    # `enable --now` starts a stopped unit and leaves a running one alone, which on an
    # upgrade means the person keeps running the old engine until they next sign in. apt
    # says so plainly ("User sessions running outdated binaries"), and it was happening
    # here. `restart` starts a stopped unit too, so one line covers install and upgrade.
    as_user "$1" "$2" "$3" systemctl --user enable app-mkcplus@daemon.service
    as_user "$1" "$2" "$3" systemctl --user restart app-mkcplus@daemon.service
    # And the window, which is what a person actually sees. Its autostart entry only runs
    # at the next sign-in, so without this an install ends with MKC+ running and nothing on
    # screen, and the desktop's own consent dialog arrives with nothing to explain it. The
    # window keeps one instance, so a second start is a no-op.
    #
    # It is handed to the person's own systemd rather than started here. A child of this
    # script lives in the session `runuser` opens and dies with it: on Fedora 44 that
    # killed the window within a second of the install finishing, whatever `setsid` and
    # `nohup` were wrapped around it. A transient unit belongs to the user manager, which
    # outlives the install and hands it the session's own environment, so the desktop,
    # the display and the session type all arrive without being copied across by hand.
    as_user "$1" "$2" "$3" systemd-run --user --collect --quiet --unit mkcplus-ui \
        /usr/bin/mkcplus-ui
}

disable_one() {
    as_user "$1" "$2" "$3" systemctl --user disable --now mkcplus.service app-mkcplus@daemon.service
    stop_window_one "$1" "$2" "$3"
}

# The window is nobody's service: it is started by its autostart entry and keeps itself
# alive for the tray, so removing the package leaves it on screen with its own program
# deleted under it. Ask it to go.
stop_window_one() {
    runuser -u "$1" -- pkill -x mkcplus-ui >/dev/null 2>&1 || true
}

# Never enable for the whole machine. systemd says why when you try to undo one as
# yourself: "unit files have been enabled in global scope ... they will still be started
# automatically after a successful disablement in user scope". That left Start at login
# unable to turn the engine off. Whoever first signs in later still gets MKC+: the window's
# own autostart entry is installed for everyone, and the window starts the engine. An
# install from before this is undone here, and so is `mkcplus.service`, the unit's name
# before 0.4.57: `disable` still takes its symlink away once the package manager has
# removed the file it pointed at, though it answers non-zero for the unit it can no longer
# read.
unglobal() {
    systemctl --global disable mkcplus.service app-mkcplus@daemon.service >/dev/null 2>&1 || true
}

# The software cursor MKC+ asks for in a virtual machine lives in each person's own
# settings (`linux::software_cursor_in_virtual_machine`): it goes with the package, or the
# desktop keeps drawing its pointer itself after MKC+ is gone.
forget_pointer() {
    getent passwd | cut -d: -f6 | sort -u | while read -r home; do
        [ -n "$home" ] && rm -f "$home/.config/environment.d/90-mkcplus-pointer.conf"
    done
}

case "${1:-}" in
    enable)
        unglobal
        each_session enable_one
        ;;
    disable)
        each_session disable_one
        unglobal
        forget_pointer
        ;;
    stop-window)
        each_session stop_window_one
        ;;
    *)
        echo "usage: session.sh enable|disable|stop-window" >&2
        exit 2
        ;;
esac
