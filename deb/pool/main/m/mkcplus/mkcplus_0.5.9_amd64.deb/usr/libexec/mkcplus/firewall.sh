#!/bin/sh
# Lets MKC+ through firewalld, or takes it out again. Installed as
# /usr/libexec/mkcplus/firewall.sh and called by both the .deb's postinst and prerm and the
# .rpm's %post and %preun, like session.sh.
#
#   firewall.sh open     allow the mkcplus service in every zone a home or office network
#                        may be put in
#   firewall.sh close    take it out of every zone, before its definition goes
#
# A firewalld that keeps everything out but a few services (Fedora's Server and Cloud
# editions, RHEL, a person's own "public" zone) otherwise keeps every other device away:
# none is found and none can join, and MKC+ cannot read the rules to say why without an
# administrator's password. The service is /usr/lib/firewalld/services/mkcplus.xml.
#
# It opens once per machine, not on every upgrade: a person who takes MKC+ out of a zone
# afterwards keeps that choice. The marker below remembers it was done. ufw is left alone,
# since Ubuntu ships it off, and someone who turns it on chooses its rules.
set -e

MARKER=/var/lib/mkcplus/firewall-opened

running() {
    command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld 2>/dev/null
}

case "$1" in
open)
    [ -e "$MARKER" ] && exit 0
    if running; then
        # firewalld reads service definitions as it starts or reloads, and a reload is what
        # Fedora's own packages do after installing one (%firewalld_reload).
        firewall-cmd --reload >/dev/null 2>&1 || true
        # Every zone, not only the active ones: a laptop that later joins a network firewalld
        # puts in another zone ("home", "work") stayed closed there. Not the zones that keep
        # everything out (drop, block) or face the internet (external, dmz), which their
        # owner chose for that; trusted lets everything in already.
        zones=$(firewall-cmd --get-zones 2>/dev/null | tr ' ' '\n' | grep -vxE 'drop|block|trusted|external|dmz' || true)
        for zone in $zones; do
            firewall-cmd --zone="$zone" --add-service=mkcplus >/dev/null 2>&1 || true
            firewall-cmd --permanent --zone="$zone" --add-service=mkcplus >/dev/null 2>&1 || true
        done
    elif command -v firewall-offline-cmd >/dev/null 2>&1; then
        # Installed but not running: its default zone, for when it starts.
        firewall-offline-cmd --add-service=mkcplus >/dev/null 2>&1 || true
    else
        exit 0
    fi
    mkdir -p "$(dirname "$MARKER")"
    : >"$MARKER"
    ;;
close)
    # A zone that names a service with no definition makes firewalld refuse the whole
    # zone as it loads, so the service leaves every zone before the package's files do.
    if running; then
        for zone in $(firewall-cmd --get-zones 2>/dev/null); do
            firewall-cmd --permanent --zone="$zone" --remove-service=mkcplus >/dev/null 2>&1 || true
            firewall-cmd --zone="$zone" --remove-service=mkcplus >/dev/null 2>&1 || true
        done
    elif command -v firewall-offline-cmd >/dev/null 2>&1; then
        for zone in $(firewall-offline-cmd --get-zones 2>/dev/null); do
            firewall-offline-cmd --zone="$zone" --remove-service=mkcplus >/dev/null 2>&1 || true
        done
    fi
    rm -f "$MARKER"
    ;;
*)
    echo "usage: firewall.sh open|close" >&2
    exit 2
    ;;
esac
