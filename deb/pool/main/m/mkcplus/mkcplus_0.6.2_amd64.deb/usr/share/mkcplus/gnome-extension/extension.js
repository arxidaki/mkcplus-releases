// MKC+ window places: where the app in front has its windows, which app a click at a point
// reaches, a picture of the screen, and the list of windows, for MKC+'s engine on this
// computer (docs/plans/agents.md, UI trees on Linux, asking before an agent uses an app,
// and a look; docs/plans/agents-background.md, find and windows). GNOME on Wayland gives
// another program none of these, and its screenshot portal cannot ask a program without a
// window of its own. Only the focused app's windows' places and an app's name are told
// to any program on the session bus, and only when asked; a picture and the list of every
// window only to MKC+'s engine. MKC+ runs this while agents may use the computer.

Gio._promisify(Shell.Screenshot.prototype, 'screenshot', 'screenshot_finish');

import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import St from 'gi://St';
import Clutter from 'gi://Clutter';
import Mtk from 'gi://Mtk';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Keyboard from 'resource:///org/gnome/shell/ui/status/keyboard.js';

const NAME = 'com.mkcplus.Windows';
// MKC+'s question window, by its title (apps/mkcplus-ui/src/agent_prompt.rs), and its gap
// from the screen's edges.
const QUESTION = 'MKC+ question';
const MARGIN = 6;
const PATH = '/com/mkcplus/Windows';
// What this extension can do, for MKC+'s engine to ask: GNOME on Wayland loads a new
// version only at the next sign-in, so the engine may meet an older one. 2: Windows.
// 3: Layers. 4: CaptureWindow. 5: PersonApps, BadgeWindows.
const VERSION = 5;
const XML = `<node>
  <interface name="com.mkcplus.Windows">
    <method name="Version">
      <arg type="u" direction="out" name="version"/>
    </method>
    <method name="Windows">
      <arg type="a(tussssbbb(iiii)(iiii))" direction="out" name="windows"/>
    </method>
    <method name="Layers">
      <arg type="a(tusss(iiii))" direction="out" name="layers"/>
    </method>
    <method name="Focused">
      <arg type="a(ussiiiiiiii)" direction="out" name="windows"/>
    </method>
    <method name="Front">
      <arg type="s" direction="out" name="app"/>
      <arg type="s" direction="out" name="name"/>
    </method>
    <method name="Commit">
      <arg type="s" direction="in" name="text"/>
      <arg type="b" direction="out" name="committed"/>
    </method>
    <method name="Layout">
      <arg type="u" direction="out" name="index"/>
    </method>
    <method name="SetLayout">
      <arg type="u" direction="in" name="index"/>
      <arg type="b" direction="out" name="switched"/>
    </method>
    <method name="Raise">
      <arg type="s" direction="in" name="app"/>
      <arg type="b" direction="out" name="raised"/>
    </method>
    <method name="Badge">
      <arg type="s" direction="in" name="name"/>
      <arg type="b" direction="in" name="dark"/>
      <arg type="b" direction="in" name="arrow"/>
      <arg type="b" direction="in" name="waiting"/>
    </method>
    <method name="PersonInput">
      <arg type="x" direction="out" name="ago_ms"/>
    </method>
    <method name="PersonApps">
      <arg type="a(ssx)" direction="out" name="apps"/>
    </method>
    <method name="BadgeWindows">
      <arg type="a(sst)" direction="in" name="badges"/>
      <arg type="b" direction="in" name="dark"/>
    </method>
    <method name="Screenshot">
      <arg type="s" direction="out" name="path"/>
    </method>
    <method name="CaptureWindow">
      <arg type="t" direction="in" name="window"/>
      <arg type="s" direction="out" name="path"/>
      <arg type="(iiii)" direction="out" name="frame"/>
      <arg type="b" direction="out" name="minimized"/>
    </method>
    <method name="At">
      <arg type="i" direction="in" name="x"/>
      <arg type="i" direction="in" name="y"/>
      <arg type="s" direction="out" name="app"/>
      <arg type="s" direction="out" name="name"/>
    </method>
  </interface>
</node>`;

const KINDS = new Map([
    [Meta.WindowType.NORMAL, 'normal'],
    [Meta.WindowType.DIALOG, 'dialog'],
    [Meta.WindowType.MODAL_DIALOG, 'dialog'],
    [Meta.WindowType.DROPDOWN_MENU, 'menu'],
    [Meta.WindowType.POPUP_MENU, 'menu'],
    [Meta.WindowType.COMBO, 'menu'],
    [Meta.WindowType.MENU, 'menu'],
    [Meta.WindowType.UTILITY, 'dialog'],
]);

// The badge of an agent at work (docs/plans/agents.md decision 14, 3.6), as the Mac and
// Windows draw it (crates/mkcplus-platform/src/badge.rs): a pill with the agent's name
// beside the pointer, dark or light as MKC+'s window is, and MKC+'s arrow in place of the
// system's pointer while the agent drives. Sizes in points, times in milliseconds.
const PILL = {height: 24, pad: 10, text: 12, offset: [14, 20], gap: 4};
const ARROW = {size: [17.5, 20], tip: [8.5 / 64 * 17.5, 5.5 / 73 * 20]};
const FADE_IN = 120;
const FADE_OUT = 220;
const LEAST = 1200;
const WAITING = 0.5;

class Badge {
    constructor(arrowFile) {
        this._arrowFile = arrowFile;
        this._name = '';
        this._shownAt = 0;
        this._hiding = 0;
        this._inhibits = 0;
        this._drives = false;
        this._left = false;
        this._unfocus = false;
    }

    // What the engine wants shown: no name for nothing.
    set(name, dark, arrow, waiting) {
        if (!name) {
            this._leave();
            return;
        }
        // Back before it went: the fade stops where it is.
        if (this._hiding > 0)
            GLib.source_remove(this._hiding);
        this._hiding = 0;
        this._pill?.remove_all_transitions();
        this._build();
        if (!this._name)
            this._shownAt = GLib.get_monotonic_time() / 1000;
        this._name = name;
        this._pill.text = name;
        this._pill.style = dark
            ? 'background-color: rgba(28,28,30,0.86); border: 1px solid rgba(255,255,255,0.22); color: #ffffff;'
            : 'background-color: rgba(255,255,255,0.92); border: 1px solid rgba(0,0,0,0.16); color: #1c1c1e;';
        this._pill.style += ` border-radius: ${PILL.height / 2}px; padding: 0 ${PILL.pad}px;` +
            ` height: ${PILL.height}px; font-size: ${PILL.text}px;`;
        const strength = waiting ? WAITING : 1;
        this._pill.ease({opacity: Math.round(255 * strength), duration: FADE_IN,
            mode: Clutter.AnimationMode.EASE_OUT_QUAD});
        const drives = arrow && !waiting;
        this._drives = drives;
        this._arrow.visible = drives;
        this._arrow.opacity = 255;
        this._focusKept(drives);
        this._cursor(!drives);
        this._follow();
    }

    // Mutter takes the pointer's focus from the window under it while the pointer is
    // hidden (as for touch), so a click there reaches nothing: GTK saw the pointer leave
    // and activated no button (GNOME 50 and 51, 2026-11-21). While MKC+'s arrow stands in
    // for the pointer, the window under it keeps the focus, as for a remote desktop.
    _focusKept(kept) {
        if (kept === this._unfocus)
            return;
        const seat = global.stage.context?.get_backend().get_default_seat();
        if (!seat)
            return;
        if (kept)
            seat.inhibit_unfocus();
        else
            seat.uninhibit_unfocus();
        this._unfocus = kept;
    }

    // Out of the way for a moment, for a picture of the screen the agent looks at.
    leftOut(out) {
        this._left = out;
        if (!this._group)
            return;
        this._group.visible = !out;
        if (!out) {
            // A screenshot brings the system's pointer back while the shell still counts
            // it hidden, and leaves the stage's order changed (Ubuntu's GNOME 50.1, which
            // draws the pointer itself on a virtual machine, 2026-11-20): above everything
            // again, and the pointer hidden afresh while the arrow stands in for it.
            if (this._drives) {
                this._cursor(true);
                global.backend.get_cursor_tracker().inhibit_cursor_visibility();
                this._inhibits++;
            }
            this._follow();
        }
    }

    destroy() {
        if (this._hiding > 0)
            GLib.source_remove(this._hiding);
        this._hiding = 0;
        this._cursor(true);
        this._focusKept(false);
        if (this._moved)
            global.backend.get_cursor_tracker().disconnect(this._moved);
        this._moved = 0;
        this._group?.destroy();
        this._group = null;
        this._pill = null;
        this._arrow = null;
        this._name = '';
        this._drives = false;
    }

    _build() {
        if (this._group)
            return;
        this._group = new St.Widget({reactive: false, can_focus: false, track_hover: false});
        this._pill = new St.Label({y_align: Clutter.ActorAlign.CENTER, opacity: 0});
        this._pill.clutter_text.y_align = Clutter.ActorAlign.CENTER;
        this._arrow = new St.Icon({
            gicon: Gio.FileIcon.new(this._arrowFile),
            icon_size: ARROW.size[1],
            style: 'icon-shadow: 0 2px 3.5px rgba(0,0,0,0.7);',
            visible: false,
        });
        this._group.add_child(this._arrow);
        this._group.add_child(this._pill);
        global.stage.add_child(this._group);
        this._group.visible = !this._left;
        this._moved = global.backend.get_cursor_tracker().connect('position-invalidated',
            () => {
                // A pointer that moves may show itself again (Ubuntu's GNOME 50.1).
                if (this._drives && !this._left)
                    this._cursor(false);
                this._follow();
            });
    }

    // Beside the pointer, and above or left of it at a screen's edge.
    _follow() {
        if (!this._group)
            return;
        if (global.stage.get_last_child() !== this._group)
            global.stage.set_child_above_sibling(this._group, null);
        const [x, y] = global.get_pointer();
        // The arrow's picture is square: its 17.5 points wide shape sits in the middle.
        const inset = (ARROW.size[1] - ARROW.size[0]) / 2;
        this._arrow.set_position(Math.round(x - ARROW.tip[0] - inset), Math.round(y - ARROW.tip[1]));
        const monitor = global.display.get_monitor_geometry(
            global.display.get_monitor_index_for_rect(new Mtk.Rectangle({x, y, width: 1, height: 1})));
        const [, width] = this._pill.get_preferred_width(-1);
        let px = x + PILL.offset[0];
        let py = y + PILL.offset[1];
        if (px + width > monitor.x + monitor.width)
            px = x - width - PILL.gap;
        if (py + PILL.height > monitor.y + monitor.height)
            py = y - PILL.height - PILL.gap;
        this._pill.set_position(Math.round(px), Math.round(py));
    }

    // The system's pointer: hidden while MKC+'s arrow stands in for it.
    // By whether it shows now, not by what was asked before: something else may show it.
    _cursor(visible) {
        const tracker = global.backend.get_cursor_tracker();
        if (!visible) {
            if (tracker.get_pointer_visible()) {
                tracker.inhibit_cursor_visibility();
                this._inhibits++;
            }
        } else {
            for (; this._inhibits > 0; this._inhibits--)
                tracker.uninhibit_cursor_visibility();
        }
    }

    // The agent let go: the system's pointer back at once, the pill after it has shown
    // long enough not to blink, then gone.
    _leave() {
        if (!this._name || this._hiding)
            return;
        this._cursor(true);
        this._focusKept(false);
        this._drives = false;
        if (this._arrow)
            this._arrow.visible = false;
        const shown = GLib.get_monotonic_time() / 1000 - this._shownAt;
        this._hiding = GLib.timeout_add(GLib.PRIORITY_DEFAULT, Math.max(0, LEAST - shown), () => {
            // Fading: -1, so a return stops the fade and a finished fade takes it away.
            this._hiding = -1;
            this._pill?.ease({opacity: 0, duration: FADE_OUT, mode: Clutter.AnimationMode.EASE_IN_QUAD,
                onComplete: () => {
                    if (this._hiding === -1)
                        this.destroy();
                }});
            return GLib.SOURCE_REMOVE;
        });
    }
}

// The badges of agents working in one app each in the background
// (docs/plans/agents-background.md 3.3, decision 7): the agent's name on its app's window,
// in the title bar's corner. Each is a child of the window's own actor, so it is ordered
// directly above that window: the windows over it cover it, and it goes with the window
// as it moves, minimizes or leaves the workspace. It takes no input.
const CORNER = {right: 56, top: 10};

class WindowBadges {
    constructor() {
        this._shown = [];
        this._out = false;
    }

    // [name, app, window id] each, the window 0 for the app's front window.
    set(badges, dark) {
        this.clear();
        for (const [name, app, id] of badges) {
            const window = this._find(app, id);
            const actor = window?.get_compositor_private();
            if (!actor)
                continue;
            const label = new St.Label({text: name, reactive: false, can_focus: false,
                track_hover: false, y_align: Clutter.ActorAlign.CENTER});
            label.clutter_text.y_align = Clutter.ActorAlign.CENTER;
            label.style = (dark
                ? 'background-color: rgba(28,28,30,0.86); border: 1px solid rgba(255,255,255,0.22); color: #ffffff;'
                : 'background-color: rgba(255,255,255,0.92); border: 1px solid rgba(0,0,0,0.16); color: #1c1c1e;') +
                ` border-radius: ${PILL.height / 2}px; padding: 0 ${PILL.pad}px;` +
                ` height: ${PILL.height}px; font-size: ${PILL.text}px;`;
            label.visible = !this._out;
            actor.add_child(label);
            const entry = {label, window, signals: []};
            const place = () => {
                const frame = window.get_frame_rect();
                const buffer = window.get_buffer_rect();
                const [, width] = label.get_preferred_width(-1);
                label.set_position(Math.round(frame.x - buffer.x + frame.width - width - CORNER.right),
                    Math.round(frame.y - buffer.y + CORNER.top));
            };
            place();
            entry.signals.push(window.connect('position-changed', place));
            entry.signals.push(window.connect('size-changed', place));
            entry.signals.push(window.connect('unmanaged', () => this._drop(entry)));
            this._shown.push(entry);
        }
    }

    // The window by its id, else the app's window most recently used.
    _find(app, id) {
        if (id) {
            const actor = global.get_window_actors().find(one => one.get_meta_window()?.get_id() === id);
            if (actor)
                return actor.get_meta_window();
        }
        const found = Shell.AppSystem.get_default().lookup_app(`${app}.desktop`);
        return found?.get_windows()?.[0] ?? null;
    }

    // Out of a picture for a moment, as the pill is.
    leftOut(out) {
        this._out = out;
        for (const entry of this._shown)
            entry.label.visible = !out;
    }

    _drop(entry) {
        for (const signal of entry.signals)
            entry.window.disconnect(signal);
        entry.signals = [];
        entry.label.destroy();
        this._shown = this._shown.filter(one => one !== entry);
    }

    clear() {
        for (const entry of this._shown.slice())
            this._drop(entry);
    }
}

export default class Places {
    enable() {
        // MKC+'s question to the person (an agent asks to be allowed): by the tray, top
        // right, above the other windows, as on a Mac. Wayland lets no program place its own.
        // It takes no keys from the person's app: Mutter gives a new window the focus,
        // which GTK cannot refuse on Wayland, so the window that had it gets it back.
        this._created = global.display.connect('window-created', (_display, window) => {
            const before = global.display.focus_window;
            const keepFocus = () => {
                if (!before || before === window || before.get_title() === QUESTION)
                    return;
                if (global.display.focus_window !== window)
                    return;
                try {
                    if (before.get_compositor_private())
                        before.activate(global.get_current_time());
                } catch {}
            };
            const place = () => {
                if (window.get_title() !== QUESTION)
                    return false;
                const area = Main.layoutManager.getWorkAreaForMonitor(Main.layoutManager.primaryIndex);
                const frame = window.get_frame_rect();
                window.move_frame(true, area.x + area.width - frame.width - MARGIN, area.y + MARGIN);
                window.make_above();
                keepFocus();
                // Mutter may focus it only as it maps, after this.
                GLib.timeout_add(GLib.PRIORITY_DEFAULT, 150, () => {
                    keepFocus();
                    return GLib.SOURCE_REMOVE;
                });
                return true;
            };
            if (place())
                return;
            const shown = window.connect('shown', () => {
                window.disconnect(shown);
                place();
            });
        });
        // A person's input: from a device of the computer's own, which has a device file.
        // What MKC+ and other programs inject comes through virtual devices, which have none.
        this._personAt = -1;
        this._input = global.stage.connect('captured-event', (_stage, event) => {
            switch (event.type()) {
            case Clutter.EventType.MOTION:
            case Clutter.EventType.BUTTON_PRESS:
            case Clutter.EventType.KEY_PRESS:
            case Clutter.EventType.SCROLL:
            case Clutter.EventType.TOUCH_BEGIN: {
                const device = event.get_source_device();
                if (device?.get_device_node())
                    this._personAt = GLib.get_monotonic_time();
                if (device?.get_device_node() || this._lastReal)
                    this._personApp(event);
                break;
            }
            }
            return Clutter.EVENT_PROPAGATE;
        });
        // The shell does not show an extension a real mouse's motion as its device's, but it
        // says when the last device used changes: a real one after MKC+'s input is a person.
        this._lastReal = false;
        this._lastDevice = global.backend.connect('last-device-changed', (_backend, device) => {
            this._lastReal = !!device?.get_device_node();
            if (this._lastReal)
                this._personAt = GLib.get_monotonic_time();
        });
        this._personApps = new Map();
        this._motion = null;
        this._background = false;
        const arrow = Gio.File.new_for_uri(import.meta.url).get_parent().get_child('arrow.svg');
        this._badge = new Badge(arrow);
        this._windowBadges = new WindowBadges();
        this._object = Gio.DBusExportedObject.wrapJSObject(XML, this);
        this._object.export(Gio.DBus.session, PATH);
        this._owner = Gio.bus_own_name_on_connection(
            Gio.DBus.session, NAME, Gio.BusNameOwnerFlags.NONE, null, null);
    }

    disable() {
        if (this._created)
            global.display.disconnect(this._created);
        this._created = null;
        if (this._owner)
            Gio.bus_unown_name(this._owner);
        this._object?.unexport();
        this._owner = null;
        this._object = null;
        this._unwatchEngine();
        this._badge?.destroy();
        this._badge = null;
        this._windowBadges?.clear();
        this._windowBadges = null;
        if (this._input)
            global.stage.disconnect(this._input);
        this._input = null;
        if (this._lastDevice)
            global.backend.disconnect(this._lastDevice);
        this._lastDevice = null;
    }

    // How long ago a person last used this computer's own mouse, keyboard or screen, in
    // milliseconds; -1 for never since the extension started.
    PersonInput() {
        const now = GLib.get_monotonic_time();
        let at = this._personAt;
        // While a device of the computer's own is the last used, the idle clock is the
        // person's: they are still moving it.
        if (this._lastReal) {
            const idle = global.backend.get_core_idle_monitor().get_idletime();
            at = Math.max(at, now - idle * 1000);
        }
        if (at < 0)
            return -1;
        return Math.floor((now - at) / 1000);
    }

    // Which app a person's own input went to (docs/plans/agents-background.md D3): keys
    // to the focused window's, the pointer to the window's under it, "system" for the top
    // bar, the dock and the desktop, "?" for a window of no app. Finding the window under
    // the pointer walks every window, which is too much for each move of a fast mouse on
    // the shell's own thread: while no agent works in the background a move only notes
    // where it was, and that last move is placed when a click, a key or the engine asks.
    _personApp(event) {
        const now = GLib.get_monotonic_time();
        if (event.type() === Clutter.EventType.KEY_PRESS) {
            this._placeMotion();
            this._personApps.set(this.Front()[0] || '?', now);
            return;
        }
        const [x, y] = event.get_coords();
        if (event.type() === Clutter.EventType.MOTION && !this._background) {
            this._motion = [x, y, now];
            return;
        }
        this._motion = null;
        this._personApps.set(this.At(Math.round(x), Math.round(y))[0] || '?', now);
    }

    // The last move of the pointer not yet placed, at the time it came.
    _placeMotion() {
        if (!this._motion)
            return;
        const [x, y, at] = this._motion;
        this._motion = null;
        const app = this.At(Math.round(x), Math.round(y))[0] || '?';
        if ((this._personApps.get(app) ?? -1) < at)
            this._personApps.set(app, at);
    }

    // Each app's last input from this computer's own devices, how long ago in
    // milliseconds; only MKC+'s engine is told which apps the person uses.
    PersonAppsAsync(params, invocation) {
        if (!this._engine(invocation.get_sender())) {
            invocation.return_dbus_error('com.mkcplus.Windows.Error.NotAllowed',
                'Only MKC+ is told where a person works here');
            return;
        }
        this._placeMotion();
        const now = GLib.get_monotonic_time();
        const apps = [...this._personApps].map(([app, at]) => [app, '', Math.floor((now - at) / 1000)]);
        invocation.return_value(new GLib.Variant('(a(ssx))', [apps]));
    }

    // The badges of the agents working in one app each; only MKC+'s engine sets them.
    BadgeWindowsAsync([badges, dark], invocation) {
        const engine = this._engine(invocation.get_sender());
        if (!engine) {
            invocation.return_dbus_error('com.mkcplus.Windows.Error.NotAllowed',
                'Only MKC+ shows who is at work here');
            return;
        }
        this._watchEngine(engine);
        this._windowBadges.set(badges, dark);
        // An agent at work in the background: each move of the person's pointer is placed.
        this._background = badges.length > 0;
        invocation.return_value(null);
    }

    // The badge of the agent at work here; only MKC+'s engine sets it.
    BadgeAsync([name, dark, arrow, waiting], invocation) {
        const engine = this._engine(invocation.get_sender());
        if (!engine) {
            invocation.return_dbus_error('com.mkcplus.Windows.Error.NotAllowed',
                'Only MKC+ shows who is at work here');
            return;
        }
        this._watchEngine(engine);
        this._badge.set(name, dark, arrow, waiting);
        invocation.return_value(null);
    }

    // The badge lasts only as long as the engine that set it: one that quit or crashed
    // (or restarted, a new engine knowing nothing of it) takes its arrow and pill away,
    // and the system's pointer comes back. The engine asks on a connection of its own
    // each time, so its process is watched, not its name on the bus.
    _watchEngine(pid) {
        if (pid === this._watchedPid)
            return;
        this._unwatchEngine();
        this._watchedPid = pid;
        this._engineWatch = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1000, () => {
            if (GLib.file_test(`/proc/${pid}`, GLib.FileTest.EXISTS))
                return GLib.SOURCE_CONTINUE;
            this._engineWatch = 0;
            this._watchedPid = 0;
            this._badge?.destroy();
            this._windowBadges?.clear();
            this._background = false;
            return GLib.SOURCE_REMOVE;
        });
    }

    _unwatchEngine() {
        if (this._engineWatch)
            GLib.source_remove(this._engineWatch);
        this._engineWatch = 0;
        this._watchedPid = 0;
    }

    // The app in front: its desktop entry's id ("org.gnome.TextEditor") and its name;
    // "system" for the desktop, a dock, or no window with the focus.
    Front() {
        const focus = global.display.focus_window;
        if (!focus)
            return ['system', ''];
        const type = focus.get_window_type();
        if (type === Meta.WindowType.DESKTOP || type === Meta.WindowType.DOCK)
            return ['system', ''];
        return this._app(focus);
    }

    // Types text into the focused app through GNOME's input method, as its on-screen
    // keyboard does: any characters, whatever the keyboard layout. Only for MKC+'s engine.
    // False when no app in front takes text from the input method.
    CommitAsync([text], invocation) {
        if (!this._engine(invocation.get_sender())) {
            invocation.return_dbus_error('com.mkcplus.Windows.Error.NotAllowed',
                'Only MKC+ may type here');
            return;
        }
        // An X11 app (under XWayland) takes no text from the input method: MKC+ types keys.
        const focus = global.display.focus_window;
        const method = Main.inputMethod;
        if (!method || !focus || focus.get_client_type() === Meta.WindowClientType.X11) {
            invocation.return_value(new GLib.Variant('(b)', [false]));
            return;
        }
        method.commit(text);
        invocation.return_value(new GLib.Variant('(b)', [true]));
    }

    // Which of the person's keyboard layouts is in use, counted as SetLayout counts them.
    Layout() {
        const manager = Keyboard.getInputSourceManager();
        const index = this._layouts(manager).indexOf(manager.currentSource);
        return index < 0 ? 0 : index;
    }

    _layouts(manager) {
        return Object.values(manager.inputSources)
            .filter(source => source.type === 'xkb')
            .sort((a, b) => a.index - b.index);
    }

    // Switches the keyboard to the index-th of the person's keyboard layouts, as their own
    // switch would; MKC+ types a character only that layout has, then switches back. The
    // keymap GNOME makes holds its keyboard layouts in this order, input methods aside.
    SetLayout(index) {
        const source = this._layouts(Keyboard.getInputSourceManager())[index];
        if (!source)
            return false;
        source.activate(false);
        return true;
    }

    // Brings the app's most recent window in front, as a person's click on it would: GNOME
    // lets no app raise its own window without the person's activation. False when the app
    // has no window.
    Raise(id) {
        const app = Shell.AppSystem.get_default().lookup_app(`${id}.desktop`);
        const windows = app?.get_windows() ?? [];
        if (!windows.length)
            return false;
        Main.activateWindow(windows[0]);
        return true;
    }

    // A picture of the whole screen as a PNG in the runtime folder, which the caller reads
    // and removes; only for MKC+'s engine (`mkcplusd`), checked by the process that asks.
    async ScreenshotAsync(params, invocation) {
        try {
            if (!this._engine(invocation.get_sender())) {
                invocation.return_dbus_error('com.mkcplus.Windows.Error.NotAllowed',
                    'Only MKC+ may take a picture of the screen here');
                return;
            }
            const path = GLib.build_filenamev([GLib.get_user_runtime_dir(),
                `mkcplus-look-${GLib.get_monotonic_time()}.png`]);
            const file = Gio.File.new_for_path(path);
            const stream = file.replace(null, false, Gio.FileCreateFlags.PRIVATE, null);
            // The badge is left out of what the agent sees, as on a Mac and on Windows.
            this._badge.leftOut(true);
            this._windowBadges.leftOut(true);
            try {
                await new Shell.Screenshot().screenshot(false, stream);
            } finally {
                this._badge.leftOut(false);
                this._windowBadges.leftOut(false);
            }
            stream.close(null);
            invocation.return_value(new GLib.Variant('(s)', [path]));
        } catch (error) {
            invocation.return_dbus_error('com.mkcplus.Windows.Error.Failed', `${error}`);
        }
    }

    // A picture of one window as a PNG in the runtime folder, which the caller reads and
    // removes, with the window's frame in the desktop's pixels and whether it is minimized
    // (docs/plans/agents.md 3.18). Mutter paints the window's own surface offscreen, so a
    // covered window comes whole, and a minimized one or one on another workspace from
    // the buffer it keeps; nothing over it is in the picture, and the window is not raised,
    // focused or restored. Only for MKC+'s engine: what a window shows is the person's.
    async CaptureWindowAsync([id], invocation) {
        let path = null;
        try {
            if (!this._engine(invocation.get_sender())) {
                invocation.return_dbus_error('com.mkcplus.Windows.Error.NotAllowed',
                    'Only MKC+ may take a picture of a window here');
                return;
            }
            const actor = global.get_window_actors()
                .find(one => one.get_meta_window()?.get_id() === id);
            const window = actor?.get_meta_window();
            if (!window) {
                invocation.return_dbus_error('com.mkcplus.Windows.Error.Gone',
                    'There is no such window now');
                return;
            }
            // The frame, where the actor (placed at the surface with its shadows) paints it.
            const frame = window.get_frame_rect();
            const buffer = window.get_buffer_rect();
            const [x, y] = actor.get_position();
            const clip = new Mtk.Rectangle({
                x: Math.floor(x) + frame.x - buffer.x,
                y: Math.floor(y) + frame.y - buffer.y,
                width: frame.width,
                height: frame.height,
            });
            // The badges are not in what the agent sees.
            this._windowBadges.leftOut(true);
            let content;
            try {
                content = actor.paint_to_content(clip);
            } finally {
                this._windowBadges.leftOut(false);
            }
            const texture = content?.get_texture();
            if (!texture) {
                invocation.return_dbus_error('com.mkcplus.Windows.Error.Failed',
                    'GNOME painted nothing of that window');
                return;
            }
            this._sweepPictures();
            path = GLib.build_filenamev([GLib.get_user_runtime_dir(),
                `mkcplus-window-${GLib.get_monotonic_time()}.png`]);
            const file = Gio.File.new_for_path(path);
            const stream = file.replace(null, false, Gio.FileCreateFlags.PRIVATE, null);
            await new Promise((resolve, reject) => {
                Shell.Screenshot.composite_to_stream(texture, 0, 0, -1, -1, 1, null, 0, 0, 1,
                    stream, (_object, result) => {
                        try {
                            Shell.Screenshot.composite_to_stream_finish(result);
                            resolve();
                        } catch (error) {
                            reject(error);
                        }
                    });
            });
            stream.close(null);
            invocation.return_value(new GLib.Variant('(s(iiii)b)', [path,
                [frame.x, frame.y, frame.width, frame.height], window.minimized]));
        } catch (error) {
            // A picture never handed over is removed here, since the engine never sees it.
            if (path) {
                try {
                    GLib.unlink(path);
                } catch {}
            }
            invocation.return_dbus_error('com.mkcplus.Windows.Error.Failed', `${error}`);
        }
    }

    // Removes pictures of windows the engine stopped waiting for (it removes each one it
    // reads): the runtime folder is memory, and a picture shows what a window showed. Only
    // those older than 10 seconds, so a picture being handed over now is left alone.
    _sweepPictures() {
        try {
            const folder = Gio.File.new_for_path(GLib.get_user_runtime_dir());
            const names = folder.enumerate_children('standard::name',
                Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, null);
            const before = GLib.get_monotonic_time() - 10 * 1000 * 1000;
            let info;
            while ((info = names.next_file(null))) {
                const made = /^mkcplus-window-(\d+)\.png$/.exec(info.get_name());
                if (made && Number(made[1]) < before)
                    folder.get_child(info.get_name()).delete(null);
            }
            names.close(null);
        } catch {}
    }

    // Whether the bus name is MKC+'s engine, whose program is mkcplusd: its process, else 0.
    _engine(sender) {
        try {
            const reply = Gio.DBus.session.call_sync('org.freedesktop.DBus',
                '/org/freedesktop/DBus', 'org.freedesktop.DBus', 'GetConnectionUnixProcessID',
                new GLib.Variant('(s)', [sender]), null, Gio.DBusCallFlags.NONE, 1000, null);
            const [pid] = reply.deepUnpack();
            const program = GLib.file_read_link(`/proc/${pid}/exe`);
            return GLib.path_get_basename(program) === 'mkcplusd' ? pid : 0;
        } catch {
            return 0;
        }
    }

    // The app whose window a click at the point reaches, in the desktop's pixels: "system"
    // for the top bar, the dock and the desktop itself.
    At(x, y) {
        const panel = Main.panel;
        const [px, py] = panel.get_transformed_position();
        const [pw, ph] = panel.get_transformed_size();
        if (panel.visible && x >= px && y >= py && x < px + pw && y < py + ph)
            return ['system', ''];
        const actors = global.get_window_actors().slice().reverse();
        for (const actor of actors) {
            const window = actor.get_meta_window();
            if (!window || window.minimized || !window.showing_on_its_workspace())
                continue;
            const frame = window.get_frame_rect();
            if (x < frame.x || y < frame.y || x >= frame.x + frame.width || y >= frame.y + frame.height)
                continue;
            const type = window.get_window_type();
            if (type === Meta.WindowType.DESKTOP || type === Meta.WindowType.DOCK)
                return ['system', ''];
            return this._app(window);
        }
        return ['system', ''];
    }

    Version() {
        return VERSION;
    }

    // Every window a person could switch to and the menus and dialogs over them, top of the
    // stack first, on every workspace, minimized ones too: its id, its process, its kind,
    // its app's id and name, its title, whether it has the focus, is minimized or is on
    // another workspace, its frame and its surface with the shadows. Only for MKC+'s
    // engine: the titles of every window are the person's.
    WindowsAsync(params, invocation) {
        if (!this._engine(invocation.get_sender())) {
            invocation.return_dbus_error('com.mkcplus.Windows.Error.NotAllowed',
                'Only MKC+ may list the windows here');
            return;
        }
        const focus = global.display.focus_window;
        const workspace = global.workspace_manager.get_active_workspace();
        const windows = [];
        for (const actor of global.get_window_actors().slice().reverse()) {
            const window = actor.get_meta_window();
            if (!window)
                continue;
            const kind = KINDS.get(window.get_window_type());
            if (!kind)
                continue;
            const [app, name] = this._app(window);
            const other = !window.is_on_all_workspaces() && !window.located_on_workspace(workspace);
            const frame = window.get_frame_rect();
            const buffer = window.get_buffer_rect();
            windows.push([window.get_id(), window.get_pid(), kind, app, name,
                window.get_title() ?? '', window === focus, window.minimized, other,
                [frame.x, frame.y, frame.width, frame.height],
                [buffer.x, buffer.y, buffer.width, buffer.height]]);
        }
        invocation.return_value(new GLib.Variant('(a(tussssbbb(iiii)(iiii)))', [windows]));
    }

    // Every window that shows on this workspace, of every kind (tooltips, splash screens and
    // popups too), top first, for MKC+'s engine to hide what an agent may not see
    // (docs/plans/agents.md 3.16): its id, its process, its kind ("system" for the desktop
    // and a dock), its app's id and name, its frame. Shell's own chrome is no window and is
    // the system's, but the parts of it that show other apps' content come first, with id
    // and process 0: the overview and a window switcher ("switcher"), a notification banner
    // and the calendar's list of notifications ("notification").
    LayersAsync(params, invocation) {
        if (!this._engine(invocation.get_sender())) {
            invocation.return_dbus_error('com.mkcplus.Windows.Error.NotAllowed',
                'Only MKC+ may list the windows here');
            return;
        }
        const layers = this._chrome();
        // Mutter keeps the windows of every workspace, and one on another workspace is
        // "showing on its workspace" too: only this workspace's, sticky ones included.
        const workspace = global.workspace_manager.get_active_workspace();
        for (const actor of global.get_window_actors().slice().reverse()) {
            const window = actor.get_meta_window();
            if (!window || window.minimized || !window.showing_on_its_workspace())
                continue;
            if (!window.located_on_workspace(workspace))
                continue;
            const type = window.get_window_type();
            const kind = type === Meta.WindowType.DESKTOP || type === Meta.WindowType.DOCK
                ? 'system' : (KINDS.get(type) ?? 'other');
            const [app, name] = this._app(window);
            const frame = window.get_frame_rect();
            layers.push([window.get_id(), window.get_pid(), kind, app, name,
                [frame.x, frame.y, frame.width, frame.height]]);
        }
        invocation.return_value(new GLib.Variant('(a(tusss(iiii)))', [layers]));
    }

    // Shell's chrome that shows other apps' content, as layers, top first.
    _chrome() {
        const layers = [];
        const add = (kind, actor) => {
            if (!actor || !actor.visible || !actor.mapped)
                return;
            const [x, y] = actor.get_transformed_position();
            const [width, height] = actor.get_transformed_size();
            if (width > 0 && height > 0)
                layers.push([0, 0, kind, '', '', [Math.floor(x), Math.floor(y),
                    Math.ceil(width), Math.ceil(height)]]);
        };
        if (Main.overview.visible || Main.overview.animationInProgress)
            layers.push([0, 0, 'switcher', '', '', [0, 0, global.stage.width, global.stage.height]]);
        for (const child of Main.uiGroup.get_children()) {
            if (/SwitcherPopup$/.test(child.constructor?.name ?? ''))
                add('switcher', child);
        }
        try {
            if (Main.messageTray._banner)
                add('notification', Main.messageTray._bannerBin);
            const dateMenu = Main.panel.statusArea.dateMenu;
            if (dateMenu?.menu?.isOpen)
                add('notification', dateMenu.menu.actor);
        } catch {
            // A Shell whose message tray is built otherwise: the overview's and switchers'
            // alone.
        }
        return layers;
    }

    _app(window) {
        const app = Shell.WindowTracker.get_default().get_window_app(window);
        const id = (app?.get_id() ?? '').replace(/\.desktop$/, '');
        return [id, app?.get_name() ?? window.get_title() ?? ''];
    }

    // The focused app's windows, top first: its process, the kind, the title, the frame
    // (what the person sees) and the buffer (the surface, shadows included).
    Focused() {
        const focus = global.display.focus_window;
        if (!focus)
            return [];
        const pid = focus.get_pid();
        const actors = global.get_window_actors().slice().reverse();
        const windows = [];
        for (const actor of actors) {
            const window = actor.get_meta_window();
            if (!window || window.get_pid() !== pid || window.minimized || !window.showing_on_its_workspace())
                continue;
            const kind = KINDS.get(window.get_window_type());
            if (!kind)
                continue;
            const frame = window.get_frame_rect();
            const buffer = window.get_buffer_rect();
            windows.push([pid, window === focus ? `${kind}*` : kind, window.get_title() ?? '',
                frame.x, frame.y, frame.width, frame.height,
                buffer.x, buffer.y, buffer.width, buffer.height]);
        }
        return windows;
    }
}
