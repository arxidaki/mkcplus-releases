#!/bin/sh
# Keep MKC+ up to date from its own repository, and touch nothing else on the machine.
#
# Every other platform updates itself: the Mac and the PCs replace their own programs, and
# a phone hands the new app to Android's installer. A Linux package cannot do that, because
# its files belong to root and the engine runs as the person. The system's own package
# manager can, which is what the repository is for (docs/plans/linux.md 5.5), and this is
# what asks it, once a day, from a timer that runs as root. No password is ever asked for,
# because nobody is asked at all.
#
# It names `mkcplus` and only `mkcplus`: nothing else on the machine is upgraded, and no
# other repository is read for it. To stop it:
#
#     sudo systemctl disable --now mkcplus-update.timer
set -eu

if command -v apt-get >/dev/null 2>&1; then
    # The lock is held by whatever else the machine is doing; wait rather than fail, and
    # update only this one source, so a daily check costs almost nothing.
    apt-get -o DPkg::Lock::Timeout=600 \
        -o Dir::Etc::sourcelist=/etc/apt/sources.list.d/mkcplus.sources \
        -o Dir::Etc::sourceparts=/dev/null \
        -o APT::Get::List-Cleanup=0 \
        update >/dev/null
    DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=600 \
        --only-upgrade -y install mkcplus
elif command -v dnf >/dev/null 2>&1; then
    dnf -y --disablerepo='*' --enablerepo=mkcplus upgrade mkcplus
else
    echo "mkcplus-update: neither apt nor dnf is here, so nothing to do" >&2
fi
